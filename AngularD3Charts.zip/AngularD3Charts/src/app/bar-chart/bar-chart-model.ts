export interface Data {
    letter: string;
    frequency: number;
}