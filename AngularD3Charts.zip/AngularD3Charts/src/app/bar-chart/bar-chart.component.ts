import { Component, OnInit, Input, ViewChild, ElementRef, OnChanges } from '@angular/core';
import * as d3 from 'd3';
import { Data } from './bar-chart-model';
import { BarService } from './bar.service';
import { svg } from 'd3';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit {

  @ViewChild('barChart', { static: true })
  private chartContainer: ElementRef;

  @Input()
  data: Data[];
  x: any;
  y: any;
  xAxisBottom: any;
  xAxisTop: any;
  yAxis: any;
  height: number = 400;
  width: number = 1050;
  tickFormat: any;
  colorRange: any;
  color: any;
  tip: any;
  margin = { top: 20, right: 30, bottom: 30, left: 100 };

  constructor() { }

  ngOnInit() {
    this.createChart();
  }

  createChart(): void {
    d3.select(".mHZChart").selectAll("*").remove();
    let svg = d3.select(".mHZChart").append("svg")
      .attr("preserveAspectRatio", "xMinYMin meet")
      .attr("viewBox", "0 0 1050 400");
    //.data(data)
    svg.transition().duration(500)
    this.chart(svg);
    this.tickFormat = d3.timeFormat("%m/%d %H:%M");
    this.x = d3.scaleLinear();
    this.y = d3.scaleOrdinal();
    this.xAxisBottom = d3.axisBottom(this.x).tickSize(-this.height);
    this.xAxisTop = d3.axisTop(this.x);
    this.yAxis = d3.axisLeft(this.y).tickFormat(this.tickFormat);
    this.colorRange = d3.scaleOrdinal(d3.schemeCategory10).range();
    this.color = d3.scaleOrdinal().range(this.colorRange);
  }

  chart(selection) {
    selection.append("g")
    .attr("class", "bards");

    selection.forEach(element => {
      
    });
  }
}
