import { Injectable } from '@angular/core';
import { Data } from './bar-chart-model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BarService {

  constructor(private _http: HttpClient) {

  }

  getData(): Observable<Data[]> {
    return this._http.get<Data[]>('../assets/data.json');
  }
}
