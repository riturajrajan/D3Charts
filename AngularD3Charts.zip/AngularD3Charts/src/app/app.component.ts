import { Component } from '@angular/core';
import { Data } from './bar-chart/bar-chart-model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularD3Charts';

  data: Observable<Data>;

  constructor(private http: HttpClient) {
   this.data = this.http.get<Data>('./assets/data.json');
 }
}
